# -*- coding: utf-8 -*-

try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *

    
    
from Algorithms import *
from AffichageDonnees import *
from Contenneurs import *
from Creations import *
from Interface import *
from Fonction import *

from lxml import etree
from random import shuffle, randint, random

import numpy as np
import sys, os
    
"""
Classe Contenant les variables global comme les agents, les tâches et les différents algorithms
"""
class Global():
    def __init__(self):
        print('init')
        """
        t = Tache('Tache 1', 15)
        t2 = Tache('Tache 2', 12)
        t3 = Tache('Tache 3', 7)
        t4 = Tache('Tache 4', 9)
        t5 = Tache('Tache 5', 6)
        t6 = Tache('Tache 6', 4)
        self.agents = [Agent('Agent 1', [t, t3, t2,t4,t5,t6]), Agent('Agent 2', [t2, t, t4, t3,t5,t6]), Agent('Agent 3', [t4, t3, t2, t,t5,t6])]
        self.taches = [t,t2, t3, t4,t5,t6]
        """
        t1 = Tache('Metro', 13)
        t2 = Tache('Maternelle', 10)
        t3 = Tache('Piscine', 9)
        t4 = Tache('Square', 6)
        t5 = Tache('Station velib', 3)
        t6 = Tache('Stade', 16)
        t7 = Tache('Commissariat', 8)
        t8 = Tache('Hopital', 11)
        t9 = Tache('HLM', 5)
        t10 = Tache('Route D14', 6)
        """t11 = Tache('T11', 3)
        t12 = Tache('T12', 4)
        t13 = Tache('T13', 7)
        t14 = Tache('T14', 12)
        t15 = Tache('T15', 3)
        t16 = Tache('T16', 4)
        t17 = Tache('T17', 7)"""
        
        T = [t1, t2, t3, t4, t5, t6, t7, t8,t9,t10]
        """
        a= [9, 1, 10, 3, 4, 5, 0, 6, 11, 7, 8, 2]
        b = [2, 3, 11, 4, 7, 1, 0, 8, 10, 5, 6, 9]
        """
        Ag = []
        for i in range(100):
            shuffle(T)
            Ag.append(Agent('Ag'+str(i), [t for t in T]))
        
        
        self.agents = Ag
        self.taches =T
        self.dureeTaches = sum([t.duree for t in self.taches]) # Temps d'éxécution de toute les tâches
        
        self.dossier = os.getcwd() # Chemin du programme
        self.dossierXML = self.dossier +'/xmlFiles' # Chemin vers les fichiers xml
        
        self.objectifs = {"Tardiness":Tardiness,
                         "UnitPenalties":UnitPenalties,
                         "Lateness":Lateness,
                         "Earliness":Earliness,
                         "AbsoluteDeviation":AbsoluteDeviation,
                         "SquaredDeviation":SquaredDeviation}
                         
        self.cost = cost
        
        
        self.bestSpeedAlgo = 'TrieDeuxADeux'
        self.algorithmsRapide = { "PositionalScoringRules":Algorithm('PositionalScoringRules', "Algorithme ordonnant les taches selon un score egale au temps qu'il reste apres la fin de la tache pour chaque agent", PositionalScoringRules),
                            "PTACopelandMethod":Algorithm('PTACopelandMethod', "Algorithme appliquant la methode PTA de Copeland", PTACopelandMethod),
                            "IterativePTAMinimax":Algorithm('IterativePTAMinimax', "Application de l'algorithme iteratif PTAMinimax", IterativePTAMinimax),
                            "MaxOccursEnd":Algorithm('MaxOccursEnd', "Application de l'algorithme MaxOccursEnd", MaxOccursEnd)}
                            
        self.typeAlgo = {"BranchAndBound":RootBranchAndBound,
                         "RechercheLocale":RechercheLocale,
                         "RechercheLocaleX":RechercheLocaleX
                         }
        
        self.pyqt = {}
        self.pyqt['Interface'] = Interface
        
        self.pyqt['ResultatWidget'] = ResultatWidget
        self.pyqt['AlgoWidget'] = AlgoWidget         
        
        self.pyqt['WidgetAgent'] = WidgetAgent        
        self.pyqt['WidgetTache'] = WidgetTache
        self.pyqt['ModifierAgent']=ModifierAgent
        self.pyqt['ButtonAlgo'] = ButtonAlgo
        self.pyqt['BranchAndBoundWidget'] = BranchAndBoundWidget

        
        self.pyqt['CreationAgent'] = CreationAgent
        self.pyqt['CreationTache'] = CreationTache
        
        self.fonction ={}
        self.fonction['findObjectByNameInList'] = findObjectByNameInList
        self.fonction['fromHexadecimalColor'] = fromHexadecimalColor
        self.fonction['hexadecimalColor'] = hexadecimalColor
        
        self.tache = Tache
        self.agent = Agent
    
    
    def choixTache(self, taches, distribution):
        liste = [0 for i in range(len(taches))]
        
        indices = [i for i in range(len(taches))]
        shuffle(indices)
        for i in indices:
            r = random()
            nb = sum([distribution[i][j] for j in range(len(distribution)) if liste[j]==0])
            val = 0
            for j in range(len(distribution)):
                if liste[j]==0:
                    val +=distribution[i][j]
                    if r < val/nb:

                        liste[j] = taches[i]
                        break
        return liste
        
        
    """
    Fonction permettant d'enregistrer les agents et les tâches
    """
    def enregistrer(self, location):
        if len(location) > 4:
            if location[-4:] != '.xml':
                location+='.xml'
        
        print('Enregistrer donnees')
        root = etree.Element('root')
        for tache in self.taches:
            t = etree.SubElement(root, 'tache')
            t.set('nom', tache.nom)
            t.set('couleurBg', tache.couleurBg)
            t.set('couleurFg', tache.couleurFg)
            t.set('duree', str(tache.duree))
            t.text=''
        
        for agent in self.agents:
            ag = etree.SubElement(root,'agent')
            ag.set('nom', agent.nom)
            ag.set('importance', str(agent.importance))
            ag.set('couleurBg', agent.couleurBg)
            ag.set('couleurFg', agent.couleurFg)
            for tache in agent.ordre:
                t = etree.SubElement(ag, 'tacheOrd')
                t.set('nom', tache.nom)
        
        with open(location,'w') as fichier:
                #En-tête du fichier xml
                #fichier.write('<?xml version="1.0" encoding="UTF_8"?>\n')
                #On écrit tous les éléments précédemment déclarer
                fichier.write(etree.tostring(root,pretty_print=True).decode('utf-8'))
        
    
    """
    Fonction permettant d'ouvrir un fichier et d'importer les agents et les tâches
    """
    def ouvrir(self, location):
        
        #Lecture du fichier et mise en placa dans une variable
        tree = etree.parse(location)
        
        taches = []
        for t in tree.xpath("/root/tache"):
            taches.append(Tache(t.get('nom'), int(t.get('duree')), t.get('couleurBg'), t.get('couleurFg')))
        
        agents = []
        for ag in tree.xpath("/root/agent"):
            print(type(ag), type(ag))
            ts = []
            for t in tree.xpath('/root/agent[@nom='+"'"+ag.get("nom")+"'"+']/tacheOrd'):
                print(t.get("nom"))
                tache = self.fonction['findObjectByNameInList'](taches, t.get("nom"))
                ts.append(tache)
            a = Agent(ag.get("nom"), ts, int(ag.get('importance')), ag.get("couleurBg"), ag.get("couleurFg"))
            agents.append(a)
        
        self.taches = taches
        self.agents = agents
    
    def creerDonnees(self, nbAgents=100, nbTaches=6, borneInf=1, borneSup=15):
        self.taches = [Tache("T"+str(i), randint(borneInf, borneSup)) for i in range(nbTaches)]
        self.agents = []
        val = [[0 for i in range(len(self.taches))] for j in range(len(self.taches))]
        dist = []
    
        l = [np.exp(i) for i in range(len(self.taches))]
        for i in range(len(self.taches)):
            shuffle(l)
            dist.append([i for i in l])


        for i in range(nbAgents):
            taches = self.choixTache(self.taches, dist)
            for j in range(len(self.taches)):
                for y in range(len(self.taches)):
                    if self.taches[j] == taches[y]:
                        val[j][y]+=1
                    
            self.agents.append(Agent("Ag"+str(i), [t for t in taches]))
        """
        l1 = [0 for i in range(len(self.taches))]
        l2 = [0 for i in range(len(self.taches))]
        for i in range(len(self.taches)):
            for j in range(len(self.taches)):
                l1[j]+= val[i][j]
                l2[j]+=dist[i][j]
            
        print(l1)
        print(l2)
        """
        print(val)
        print(dist)
    """"
    Fonction permettant d'ajouter un Agent
    """
    def ajouterAgent(self, dic):
        print('Création Agent')
        res = self.testDicAgent(dic)
        if not res:
            ordre = [self.fonction['findObjectByNameInList'](self.taches, nomTache) for nomTache in dic['ordre']]
            
            agent = Agent(dic['nom'], ordre, dic['importance'], dic['couleurBg'], dic['couleurFg'], dic['font'])
            self.agents.append(agent)
            return True, "yes"
        else:
            return False, res
    
    """"
    Fonction permettant de modifier un Agent
    """    
    def modifierAgent(self, agent, dic):
        print('Modification Agent '+agent.nom)
        
        res = self.testDicEditAgent(dic,agent)
        if not res:
            agent.nom = dic['nom']
            agent.importance = dic['importance']
            agent.ordre = [self.fonction['findObjectByNameInList'](self.taches, nomTache) for nomTache in dic['ordre']]
            agent.couleurBg = dic['couleurBg']
            agent.couleurFg = dic['couleurFg']
            agent.font = dic['font']
            agent.dicFinTache()
        
            return True, "yes"
        
        else:
            return False, res
        
    """"
    Fonction permettant d'ajouter une tâche
    """
    def ajouterTache(self, dic):
        print('Création Tache')
        res = self.testDicTache(dic)
        if not res:
            tache = Tache(dic['nom'], dic['duree'], dic['couleurBg'], dic['couleurFg'], dic['font'])
            self.taches.append(tache)
            self.dureeTaches+=tache.duree
            for agent in self.agents:
                agent.ordre.append(tache)
                agent.finTache[tache]= self.dureeTaches
            return True, "yes"
        else:
            return False, res
        
    """"
    Fonction permettant de modifier une tâche
    """
    def modifierTache(self, tache, dic):
        print('Modification tache'+tache.nom)
        res = self.testDicEditTache(dic, tache)
        if not res:
            tache.nom = dic['nom']
            tache.duree = dic['duree']
            tache.couleurBg = dic['couleurBg']
            tache.couleurFg = dic['couleurFg']
            tache.font = dic['font']
            
            return True, "yes"
        else:
            return False, res
           
           

    def testDicAgent(self, dic):
        res = ''
        print(dic['nom'])
        if self.fonction['findObjectByNameInList'](self.agents, dic['nom']) is not None:
            res+='Un agent a deja ce nom\n'
        if dic['nom'] == '':
            res+="L'agent doit avoir un nom\n"
        if ['absent' for tache in dic['ordre'] if str(tache)=='']:
            res+="L'agencement des taches n'est pas correct, tout les taches n'ont pas un crenneau\n"
        return res
        
    def testDicTache(self, dic):
        res = ''
        if self.fonction['findObjectByNameInList'](self.taches, dic['nom']) is not None:
            res+='Une tache a deja ce nom\n'
        return res
    
    def testDicEditAgent(self, dic, agent):
        res = ''
        print(dic['nom'])
        if self.fonction['findObjectByNameInList']([a for a in self.agents if a !=agent], dic['nom']) is not None:
            res+='Un agent a deja ce nom\n'
        if dic['nom'] == '':
            res+="L'agent doit avoir un nom\n"
        if ['absent' for tache in dic['ordre'] if str(tache)=='']:
            res+="L'agencement des taches n'est pas correct, tout les taches n'ont pas un crenneau\n"
        return res
        
    def testDicEditTache(self, dic, tache):
        res = ''
        if self.fonction['findObjectByNameInList']([t for t in self.taches if t !=tache], dic['nom']) is not None:
            res+='Une tache a deja ce nom\n'
        return res



"""
Classe représentant un agent
"""
class Agent():
    
    def __init__(self, nom, ordre, importance=1, couleurBg='#BBBBBB', couleurFg='#333333', font=None):
        self.nom = nom
        self.ordre = ordre
        self.importance = importance
        self.couleurBg = couleurBg
        self.couleurFg = couleurFg
        if font is None:
            self.font = QFont()
        else:
            self.font = font
        if ordre:
            self.dicFinTache()

    def dicFinTache(self):
        self.finTache = {}
        val = 0
        for tache in self.ordre:
            val+=tache.duree
            self.finTache[tache] = val

"""
Classe représentant une tâche
"""
class Tache():
    
    def __init__(self, nom, duree, couleurBg='#CCCCCC', couleurFg='#333333', font=None):
        self.nom = nom
        self.duree = duree
        self.couleurBg = couleurBg
        self.couleurFg = couleurFg
        if font is None:
            self.font = QFont()
        else:
            self.font = font
"""
Classe représentant un algorithm
"""
class Algorithm():
    
    def __init__(self, nom, description, fonction):
        self.nom = nom
        self.description = description
        self.fonction = fonction
    
    def toString(self):
        return self.nom + " "+self.description+" " +str(type(self.fonction))
