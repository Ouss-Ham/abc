# -*- coding: utf-8 -*-
try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *
        
class Interface(QMainWindow):
    
    def __init__(self, parent, Global=None):
        QMainWindow.__init__(self)
        self.parent = parent
        self.interface=self
        self.setGeometry(100,100,1200,800)
        self.Global = Global
        
        self.central = QWidget()
        self.setCentralWidget(self.central)        

        self.mainLayout = QVBoxLayout()
        self.central.setLayout(self.mainLayout)
        self.initAction()
        self.initMenu()
        self.initTaches()
        self.initBottom()

    """
    Initialisation des actions
    """
    def initAction(self):
        print('Actions')
        
        self.newAgentAct = QAction('Ajouter un agent', None)
        self.newAgentAct.setShortcut('Ctrl+a')
        self.newAgentAct.setToolTip('Ajouter un agent')
        self.newAgentAct.setStatusTip('Ajouter un agent')
        self.newAgentAct.triggered.connect(self.creationAgent)
        
        self.modAgentAct = QAction('Modifier les agents', None)
        self.modAgentAct.setShortcut('Ctrl+e')
        self.modAgentAct.setToolTip('Modifier les agents')
        self.modAgentAct.setStatusTip('Modifier les agents')
        self.modAgentAct.triggered.connect(self.modifierAgent)
        
        self.newTacheAct = QAction('Ajouter une tache', None)
        self.newTacheAct.setShortcut('Ctrl+t')
        self.newTacheAct.setToolTip('Ajouter une tache')
        self.newTacheAct.setStatusTip('Ajouter une tache')
        self.newTacheAct.triggered.connect(self.creationTache)
        
        self.openAct = QAction('Ouvrir', None)
        self.openAct.setToolTip('Ouvrir')
        self.openAct.setStatusTip('Ouvrir')
        self.openAct.triggered.connect(self.openFile)
        
        self.saveAct = QAction('Enregistrer', None)
        self.saveAct.setToolTip('Enregistrer')
        self.saveAct.setStatusTip('Enregistrer')
        self.saveAct.triggered.connect(self.saveFile)
        
        self.quitAct = QAction('Quitter', None)
        self.quitAct.setToolTip('Quitter')
        self.quitAct.setStatusTip('Quitter')
        self.quitAct.triggered.connect(self.quit)
        
        
        self.creerDataAct = QAction('Creer des donnees', None)
        self.creerDataAct.triggered.connect(self.creerData)

    """
    Initialisation du menu
    """
    def initMenu(self):
        print('Menu')
        self.menu = self.menuBar()
        
        self.fileMenu = self.menu.addMenu("Fichier")
        

        self.fileMenu.addAction(self.openAct)
        self.fileMenu.addAction(self.saveAct)
        self.fileMenu.addAction(self.quitAct)
        
        self.editionMenu = self.menu.addMenu("Edition")
        self.editionMenu.addAction(self.newAgentAct)
        self.editionMenu.addAction(self.modAgentAct)
        self.editionMenu.addAction(self.newTacheAct)
        self.editionMenu.addAction(self.creerDataAct)
        
    def initTaches(self):
        print("Taches")
        if self.mainLayout.count()>0:
            self.mainLayout.removeWidget(self.groupBoxTache)
            self.groupBoxTache.setHidden(1)
        self.HLayoutTaches = QHBoxLayout()
        
        self.groupBoxTache = QGroupBox('Taches')
        self.groupBoxTache.setStyleSheet((""".QGroupBox{background-color:#FFD0A0;
                                                border:8px solid #FFD0A0;}
                            """))
        self.groupBoxTache.setLayout(self.HLayoutTaches)
        
        self.mainLayout.insertWidget(0,self.groupBoxTache)
        
        for tache in self.Global.taches:
            WTache = self.Global.pyqt['WidgetTache'](self, tache)
            self.HLayoutTaches.addWidget(WTache)
    
    def initBottom(self):
        
        self.tabWidget= QTabWidget()
        self.tabWidget.setMinimumHeight(200)
        self.tab1 = QWidget()
        self.tab2 = QWidget()
    
        self.initAlgo()
        self.initResultat()
        
        self.mainLayout.addWidget(self.tabWidget)
    """
    Initialisation des algorithms
    """
    def initAlgo(self):
        print('Algos')
        
        self.tabWidget.removeTab(self.tabWidget.indexOf(self.tab1))
        self.tab1 = QScrollArea()
        self.algos = self.Global.pyqt['AlgoWidget'](self)
        self.tab1.setLayout(self.algos)   
        self.tabWidget.insertTab(0, self.tab1, 'Algorithmes')
        self.tabWidget.setCurrentIndex(0)

    """
    Initialisation de la liste des résultats
    """
    def initResultat(self):
        self.tabWidget.removeTab(self.tabWidget.indexOf(self.tab2))
        self.tab2= QScrollArea()
        self.resultat = self.Global.pyqt['ResultatWidget'](self)
        self.tab2.setLayout(self.resultat)       
        self.tabWidget.insertTab(1, self.tab2, 'Resultats')
        self.tabWidget.setCurrentIndex(1)

    
    def creationAgent(self):
        agentW = self.Global.pyqt['CreationAgent'](self)
        agentW.show()
    
    def creationTache(self, tache=None):
        tacheW = self.Global.pyqt['CreationTache'](self)
        tacheW.show()
    
    def modifierAgent(self):
        print("modification")
        agentsW = self.Global.pyqt['ModifierAgent'](self)
        agentsW.show()
    
    def creerData(self):
        self.Global.creerDonnees()
        self.initTaches()
        
        
    def openFile(self):
        QFileDialog().setDirectory(self.Global.dossierXML)
        fichier = QFileDialog().getOpenFileName(self, 'Open xml file','', "XML files (*.xml)")
        print(fichier)
        if fichier:
            self.Global.ouvrir(fichier)
            self.initTaches()
    
    def saveFile(self):
        QFileDialog().setDirectory(self.Global.dossierXML)
        fichier = QFileDialog().getSaveFileName(self, 'Save file', '', "XML files (*.xml)")
        if fichier:
            self.Global.enregistrer(fichier)
        
    def quit(self):
        print('Quit')
        answer=QMessageBox.question(self, 'ATTENTION!', "Voulez-vous vraiment quitter?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)  
        if answer==QMessageBox.Yes:
            self.destroy()
        
    def closeEvent(self,evnt):
        self.quit()
        evnt.ignore()
    
