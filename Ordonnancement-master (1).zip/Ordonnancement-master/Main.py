# -*- coding: utf-8 -*-
try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *
    
from Donnees import *

def main(args):
    app = QApplication(args)
    app.setStyle("plastique")

    g = Global()
    win =g.pyqt['Interface'](app, g)
    win.setWindowTitle('Ordonnancement des taches')
    win.show()
    
    app.exec_()
    
if __name__ == "__main__":
    main(sys.argv)