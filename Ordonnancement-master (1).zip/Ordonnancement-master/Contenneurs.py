# -*- coding: utf-8 -*-
try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *

from Fonction import *
    
"""
QVBoxLayout représentant l'affichage des résultats
@param interface : parent du widget
"""
class ResultatWidget(QVBoxLayout):
    
    def __init__(self, interface):
        QVBoxLayout.__init__(self)
        
        self.affichage = QScrollArea()
        self.affichage  .setStyleSheet((""".QScrollArea{background-color:#AAD0A0;}
                            """))
        self.affichage.setWidgetResizable(True)
        widget = QWidget()
        
        widget.setStyleSheet((""".QWidget{background:#a16947}
                            """))
        self.layoutAffichage = QVBoxLayout()
        self.layoutAffichage.setAlignment(Qt.AlignTop)
        
        widget.setLayout(self.layoutAffichage)
        self.affichage.setWidget(widget)
        self.addWidget(self.affichage)
        
        self.interface = interface
    """
    Ajoute un résulat à la liste
    """
    def ajouterResultat(self, resultat, nom):
        
        affichage = QGroupBox(nom)
        affichage.setStyleSheet((""".QGroupBox{background-color:#FFD0A0;
                                                border:10px solid #FFD0A0;}
                            """))
        layout=QVBoxLayout()
        affichage.setLayout(layout)
        
        hBoxLayout = QHBoxLayout()
        
        
        """ Boutons utiles """
        vLayout = QVBoxLayout()
        delete = QPushButton("Retirer")
        desc = QPushButton("Description")
        delete.clicked.connect(self.retirer(affichage))
        desc.clicked.connect(self.description(resultat[0]))
        vLayout.addWidget(desc)
        vLayout.addWidget(delete)
        hBoxLayout.addLayout(vLayout)
        
        for tache in resultat[1]:
            t = self.interface.Global.pyqt['WidgetTache'](self, tache, modification=False)
            hBoxLayout.addWidget(t)
        layout.addLayout(hBoxLayout)
        print('RETARD '+nom, self.interface.Global.cost(self.interface.Global.agents, resultat[1], self.interface.Global.objectifs['Tardiness']))
        resultat[1].reverse()
        print('Inverse Retard '+nom, self.interface.Global.cost(self.interface.Global.agents, resultat[1], self.interface.Global.objectifs['Tardiness']))

        self.layoutAffichage.addWidget(affichage)

    
    def retirer(self, w):
        def a(widget=w):
            w.hide()
        return a
        
    def description(self, desc):
        def b(desc=desc):
            print(desc)
        return b
        
"""
QVBoxLayout représentant la liste des algorithms possibles
@param interface : parent d'un widget
"""
class AlgoWidget(QVBoxLayout):
    def __init__(self, interface):
        QVBoxLayout.__init__(self)
        
        self.setAlignment(Qt.AlignTop)
        
        self.interface = interface
        self.scoringAlgo()
        self.branchAndBoundAlgo()
        self.compAlgos()
        
        self.addStretch(100)
    def scoringAlgo(self):
        self.groupScoring = QGroupBox("Algorithme rapide")
        self.groupScoring.setStyleSheet((""".QGroupBox{ background:#FFD0A0;
                                                        border:12px solid #FFD0A0;}
                            """))
        self.layoutScoringAlgo = QHBoxLayout()
        self.groupScoring.setLayout(self.layoutScoringAlgo)
        self.addWidget(self.groupScoring)
        
        for algo in self.interface.Global.algorithmsRapide.values():
            self.layoutScoringAlgo.addWidget(self.interface.Global.pyqt['ButtonAlgo'](self, algo))


    def branchAndBoundAlgo(self):
        a = self.interface.Global.pyqt['BranchAndBoundWidget'](self)
        print(a)
        self.addWidget(a)

    def compAlgos(self):
        self.groupComparaison = QGroupBox("Comparer différents alogritmes")
        
        
        
        
        
        
        