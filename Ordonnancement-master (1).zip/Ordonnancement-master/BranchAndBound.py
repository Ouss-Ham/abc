# encoding=utf8  
from time import time


class Algo():
    
    def __init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000):
        
        self.tempsStart = time()
        # Durée maximal autorisé
        self.tempsMax = tempsMax
        # Liste des agents
        self.agents = agents
        # On les tâches grâce au premier agent
        self.taches = self.agents[0].ordre
        # Boolean déterminant si on calcul les valeurs de chaques tâches pour chaque date initialement dans le but d'éviter les redondances
        self.calculValeursInitialement = calculValeursInitialement
        # Heuristique Initial
        self.methodInit = methodInit
        # Fonction mesurant l'impact entre la fin de tache dans l'ordonnancement et la fin de tache chez un agent
        self.fonction = fonction
        # Durée total des tâches
        self.duree = sum([tache.duree for tache in self.taches])
        # Ensemble des valeurs optimals local trouvées
        self.valeursOptimales = []
        
        # Si on decide de calculer initialement les valeurs        
        if self.calculValeursInitialement:
            self.initValues()
        
        # Ordonnancement initial
        self.ordonnancement = self.methodInit(self.agents)[1]
        self.ordonnancement.reverse()  
        self.specificiterAlgo()

        # Calcul du retard du premier ordonnancement et ajout en tant qu'optimum
        self.changeOptimum(self.ordonnancement, self.calculValeur(self.ordonnancement))
        
        # Temps d'initialisation de l'algorithme
        self.dureeInitialisation = time() - self.tempsStart
        
        
        # Début de l'algoritme
        self.start()
        
        
        # temps utilisé par l'algo
        self.temps = time() - self.tempsStart 
        
        
    """
    Calcul le nombre de fois que la tache est en retard à la date temps
    """
    def valeurTache(self, tache, temps):
        valeur = 0
        for ag in self.agents:
            valeur+= self.fonction(temps, ag.finTache[tache])*ag.importance
        return valeur
        
    """
    Initialisation des retard initiaux de chaques tâches pour chaques agents
    """
    def initValues(self):
        self.valeurTacheDate = {}
        for tache in self.taches:
            valeurTache = []
            for i in range(self.duree+1):
                valeurTache.append(self.valeurTache(tache, i))
            self.valeurTacheDate[tache] = valeurTache
    
    """
    Retourne l'ordonnancement
    """
    def getOrdonnancement(self, reverse=True):
        ord = [t for t in self.ordonnancement]        
        if reverse:
            ord.reverse()
        return ord
    
    """
    Changer l'optimum
    """
    def changeOptimum(self, ord, valeur):
        self.valeur = valeur
        self.ordonnancement = ord
        self.valeursOptimales.append(valeur)
    
    
    """
    Calcul de la valeur d'un ordonnancement
    @param ordonnancement : Tache ordonnée à partir de la fin
    @param reverse : Si l'ordonnancement doit être inversé
    """
    def calculValeur(self, ordonnancement):
        valeur = 0
        finOrd = self.duree
        for tache in ordonnancement:
            # Si on a calculé initialement le retard pour chaque tâche
            if self.calculValeursInitialement:
                valeur += self.valeurTacheDate[tache][finOrd]
                
            # Sinon on calcul le retard de la tâche par rapport à chaque agent
            else:
                valeur  += self.valeurTache(tache, finOrd)
            
            finOrd-=tache.duree

        return valeur
        
    """
    Spécificité de chaque algo
    """
    def specificiterAlgo(self):
        return
        
    """
    Lancement de l'agorithme
    """
    def start():
        return


"""
Racine d'un branch and bound pour le problème de l'ordonnancement
"""
class RechercheLocale(Algo):
    
    def __init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000):
        Algo.__init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000)   
    
    def start(self):
        continuer = True
        nbTache = len(self.ordonnancement)
        while continuer and (time()-self.tempsStart < self.tempsMax):
            continuer = False
            for i in range(nbTache):
                for j in range(nbTache):
                    newOrd = [t for t in self.ordonnancement]
                    newOrd[i], newOrd[j] = newOrd[j], newOrd[i]
                    valeur = self.calculValeur(newOrd)
                    if valeur < self.valeur:
                        self.changeOptimum(newOrd, valeur)
                        continuer = True
                        
class RechercheLocaleX(Algo):
    
    def __init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000):
        Algo.__init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000)   
    
    def start(self):
        continuer = True
        nbTache = len(self.ordonnancement)
        while continuer and (time()-self.tempsStart < self.tempsMax):
            continuer = False
            for i in range(nbTache):
                for j in range(nbTache):
                    newOrd = [t for t in self.ordonnancement]
                    newOrd[i], newOrd[j] = newOrd[j], newOrd[i]
                    valeur = self.calculValeur(newOrd)
                    if valeur < self.valeur:
                        self.changeOptimum(newOrd, valeur)
                        continuer = True
                        break
                if continuer:
                    break


"""
Racine d'un branch and bound pour le problème de l'ordonnancement
"""
class RootBranchAndBound(Algo):
    
    def __init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000):
        Algo.__init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax=10000)   
        
    def specificiterAlgo(self):
        
        self.nbNoeudsParcouru = 0
        # Nombre de noeuds à visiter si on élague pas
        self.nbNoeudsPotentiel = self.nbPossibleNoeuds(len(self.taches))
        # Ensemble des valeurs optimals local trouvées 
        
    """
    Début du parcours du graphe
    """
    def start(self):
        Node(self, [])    
        
    """
    Nombre de noeuds visitable
    """
    def nbPossibleNoeuds(self, n):
        if n==0:
            return 1
        else:
            return n*self.nbPossibleNoeuds(n-1) + 1
            
    def description(self):
        return ""


"""
Racine d'un branch and bound pour le problème de l'ordonnancement
"""
class Node():
    
    def __init__(self, root, ordonnancement, borneInf=0, duree=0):
        
        self.root = root
        self.ordonnancement = ordonnancement 
        self.borneInf = borneInf
        self.duree = duree
        self.root.nbNoeudsParcouru+=1
        
        # Si on est arrivé sur une feuille ( La borne inf est égale à la valeur de l'ordonnancement)
        if len(ordonnancement) == len(self.root.taches):
            if self.borneInf < self.root.valeur:
                self.root.changeOptimum(ordonnancement, self.borneInf)
                return
        
        # Liste contenant chaque tache qu'on peut ajouter avec la borne inf et la borne sup associé
        listTacheBorne = [[tache, self.calculBorneInf(tache), self.calculBorneSup(tache)] for tache in self.root.taches if tache not in ordonnancement]
        
        # On trie la liste pouvoir explorer la partie la plus intéressante
        listTrier = sorted(listTacheBorne, key=lambda colonnes : colonnes[1])
        
        for tache, borneInf, borneSup in listTrier:
    
            # Si la borne sup est inférieur au résultat alors on applique l'heuristique avec l'ordonnancement déjà présent
            if borneSup <self.root.valeur:
                retard, ordonnancement = self.calculBorneSup(tache, True) # on cherche l'ordonnancement correspondant
                self.root.changeOptimum(ordonnancement, retard)
                
            # Si la borne inf est inférieur à notre valeur optimal alors on visite cette partie de l'arbre
            if borneInf<self.root.valeur:
                # Si il reste du temps
                if (time()-self.root.tempsStart) < self.root.tempsMax:
                    Node(self.root, [t for t in self.ordonnancement]+[tache], borneInf, self.duree+tache.duree)

    """
    Borne inf des noeuds fils
    """
    def calculBorneInf(self, tache):
        # si les valeurs des tache non pas été calculé initialement
        if not self.root.calculValeursInitialement:
            val = self.root.valeurTache(tache,self.root.duree - self.duree)
            return self.borneInf+val
        else:
            val = self.root.valeurTacheDate[tache][self.root.duree - self.duree]
            return self.borneInf+val
            
    """
    Borne sup des noeuds fils
    """
    def calculBorneSup(self, tache, retourOrd=False):
        ord = [t for t in self.ordonnancement]+[tache]
        for t in self.root.taches:
            if t not in ord:
                ord.append(t)
        if retourOrd:
            return self.root.calculValeur(ord), ord
            
        return self.root.calculValeur(ord)
        