# -*- coding: utf-8 -*-

from Donnees import *
from Algorithms import *
from BranchAndBound import *
from random import randint
import matplotlib.pyplot as plt
from Fonction import *

import numpy as np
import time

"""
Créer des taches
"""
def creerTaches(nbTaches=12, borneInf=1, borneSup=15):        
    return [Tache("T"+str(i), randint(borneInf, borneSup)) for i in range(nbTaches)]

"""
Créer les agents
"""
def creerAgents(taches, nbAgents=200):
    agents = []
    for i in range(nbAgents):
        shuffle(taches)
        agents.append(Agent("Ag"+str(i+1), [t for t in taches]))
    return agents

def choixTache(taches, distribution):
    liste = [0 for i in range(len(taches))]
        
    indices = [i for i in range(len(taches))]
    shuffle(indices)
    for i in indices:
        r = random()
        nb = sum([distribution[i][j] for j in range(len(distribution)) if liste[j]==0])
        val = 0
        for j in range(len(distribution)):
            if liste[j]==0:
                val +=distribution[i][j]
                if r < val/nb:
                    liste[j] = taches[i]
                    break
    return liste
    
def creerDonnees(nbTaches=100, nbAgents=100, inf = 1, sup = 15):
    Taches = [Tache("T"+str(i), randint(inf, sup)) for i in range(nbTaches)]
    
    # creation de la distribution
    dist = []
    l = [np.exp(i) for i in range(nbTaches)]
    for i in range(nbTaches):
        shuffle(l)
        dist.append([i for i in l])
    
    agents = []
    for i in range(nbAgents):
        taches = choixTache(Taches, dist)
        agents.append(Agent("Ag"+str(i), [t for t in taches]))
    return Taches, agents
    
  
def testInitUtile():
    nbTache = 10
    listeBorneSup= [50,100,200,300,400, 500, 600, 800, 1000]
    liste = []
    for i in range(nbTache):
        n = i+4
        for sup in listeBorneSup:
            c=10
            t1=0
            t2=0
            for j in range(c):
                taches, agents = creerDonnees(n, 50, 1, sup)
                
                g1 =  RootBranchAndBound(agents, 1, PositionalScoringRules, Tardiness)
                g2 =  RootBranchAndBound(agents, 0, PositionalScoringRules, Tardiness)
                t1+=g1.temps
                t2+=g2.temps
            liste.append([n, sup, t1/c, t2/c])
            
    lg1Mieux = [[l[0], l[1]] for l in liste if l[2]<l[3]]
    lg2Mieux = [[l[0], l[1]] for l in liste if l[3]<l[2]]
    plt.scatter([l[0] for l in lg1Mieux], [l[1] for l in lg1Mieux], c='blue')
    plt.scatter([l[0] for l in lg2Mieux], [l[1] for l in lg2Mieux], c='red')
    plt.xlabel('Nombre de taches')
    plt.ylabel('Durée maximale des tâches')
    plt.show()
    return liste


def nbNoeudsVisite(nbAgent=100, nbTache=8, nombreTest=1000):
    liste = []
    for i in range(nombreTest):
        taches, agents = creerDonnees(nbTache, nbAgent, 1, 2*i+1)
        if 2*i+1 < 500:
            noeuds = RootBranchAndBound(agents, 1, PositionalScoringRules, Tardiness).nbNoeudsParcouru
        else:
            noeuds = RootBranchAndBound(agents, 0, PositionalScoringRules, Tardiness).nbNoeudsParcouru
        liste.append(noeuds)
    
    x = [5*i+1 for i in range(nombreTest)]
    y = liste
    plt.scatter(x, y, s=15)
    plt.xlabel('Durée maximale des tâches')
    plt.ylabel('Nombre de nœuds visité')
    
    fit = np.polyfit(x, y, 1)
    poly = np.poly1d(fit)
    
    plt.plot(x, [poly(x0) for x0 in x], color="red")
    
    plt.show()
        
        
def compareRecherche(nbAgent=100, nbTache=8, nombreTest=5000):
    fonction = {"Tardiness":Tardiness,
                         "UnitPenalties":UnitPenalties,
                         "Earliness":Earliness,
                         "AbsoluteDeviation":AbsoluteDeviation,
                         "SquaredDeviation":SquaredDeviation}
                         
    ecart = {}
    
    for key in fonction.keys():
        ecart[key] = []
    
    for i in range(nombreTest):
        taches, agents = creerDonnees(nbTache, nbAgent, 5, 15)
        for key, value in fonction.items():
            branch = RootBranchAndBound(agents, 1, PositionalScoringRules, value)
            recherche = RechercheLocale(agents, 1, PositionalScoringRules, value)
            val = (float(recherche.valeur) - branch.valeur)/branch.valeur
            print(key, val)
            ecart[key].append(val)
    for k in fonction.keys():
        ecart[k] = sum(ecart[k])/nombreTest
    
    return ecart



def compareScoring(nbAgent=100, nbTache=8, nombreTest=100):
    fonction = {"Tardiness":Tardiness,
                         "UnitPenalties":UnitPenalties,
                         "Earliness":Earliness,
                         "AbsoluteDeviation":AbsoluteDeviation,
                         "SquaredDeviation":SquaredDeviation}
    
    algo = {"PositionalScoringRules":Algorithm('PositionalScoringRules', "Algorithme ordonnant les taches selon un score egale au temps qu'il reste apres la fin d'une tache pour chaque agent", PositionalScoringRules),
-           "PTACopelandMethod":Algorithm('PTACopelandMethod', "Algorithme appliquant la methode PTA de Copeland", PTACopelandMethod),
-           "IterativePTAMinimax":Algorithm('IterativePTAMinimax', "Application de l'algorithm iteratif PTAMinimax", IterativePTAMinimax),
            "MaxOccursEnd":Algorithm('MaxOccursEnd', "Application de l'algorithm MaxOccursEnd", MaxOccursEnd)}    
    
    ecart = {}
    
    for key in fonction.keys():
        ecart[key] = {}
        for k in algo.keys():
            ecart[key][k] = []
    
    for i in range(nombreTest):
        taches, agents = creerDonnees(nbTache, nbAgent, 5, 15)
        
        res = {}
        for key, value in algo.items():
            res[key] = value.fonction(agents)[1]
        
        for key, value in fonction.items():
            opti = RootBranchAndBound(agents, 1, PositionalScoringRules, value)
            
            for k in ecart[key].keys():
                cout = cost(agents, res[k], value)
                ecart[key][k].append(abs((cout-opti.valeur)/opti.valeur))
    
    for value in ecart.values():
        for k in value.keys():
            value[k] = float(sum(value[k]))/nombreTest
    
    return ecart
    
    
def tempsCalcul(nbAgent=100, nbTache=8, nombreTest=100):
    fonction = {"Tardiness":Tardiness}

    ecartBranch = {}
    ecartRecherche = {}
    
    for key in fonction.keys():
        ecartBranch[key] = []
        ecartRecherche[key] = []
    
    for i in range(nombreTest):
        taches, agents = creerDonnees(nbTache, nbAgent, 5, 15)
        
        for value in fonction.values():
            branch = RootBranchAndBound(agents, 1, PositionalScoringRules, value)
            recherche = RechercheLocale(agents, 1, PositionalScoringRules, value)

            ecartBranch[key].append(branch.duree)
            print(branch.duree)
            ecartRecherche[key].append(recherche.duree)
            
            
            
    for k in fonction.keys():
        ecartBranch[k] = sum(ecartBranch[k])/nombreTest
        ecartRecherche[k] = sum(ecartRecherche[k])/nombreTest
    
    return ecartBranch, ecartRecherche

def tempsNb(nbAgent=100, nbTacheMax = 30, nbTest=100):
    
    
    liste = []
    for i in range(nbTacheMax):
        a = input('Test')
        if a=="a":
            return liste
        else:
            val = 0
            for j in range(nbTest):
                taches, agents = creerDonnees(i+1, nbAgent, 5, 15)
                recherche = RechercheLocale(agents, 1, PositionalScoringRules, Tardiness)
                
                val+=recherche.duree
            liste.append(val/nbTest)
    return liste

def pl(liste):
    plt.plot([i+1 for i in range(len(liste))], liste)
    plt.show()
    
    
    
def pourcentageNoeudVisited():
    liste = []
    m=13
    n = 100
    for i in range(5,m):
        tot = 0
        poss = 0
        for j in range(n):
            taches, agents = creerDonnees(i, 50, 5, 15)
            g=RootBranchAndBound(agents, 1, PositionalScoringRules, Tardiness)
            tot += g.nbNoeudsParcouru
            poss = g.nbNoeudsPotentiel
        liste.append(tot/(n*poss))
    
    plt.scatter([i for i in range(5,m)], liste)
    plt.xlabel('Nombres de taches')
    plt.ylabel('Pourcentage de noeuds visité')
    plt.show()
    
    return liste
"""

"""
def test():
    grapheInit = [[]]
    grapheSansInit = [[]]
     
    listeBorneInf = [10,50,100,200,500,1000,2000]
    
    for i in range(5,11):
        for k in listeBorneInf:
            listeInit = []
            listeSansInit = []
            for j in range(2):
                print(i)

                agents = creerAgents(creerTaches(nbTaches=i, borneInf=1, borneSup=k), 50)
                listeInit.append(InitTacheLateMethod(agents)[2])
                listeSansInit.append(classicalLateMethod(agents)[2])
            
            grapheInit.append(listeInit)
            grapheSansInit.append(listeSansInit)
            
            
            
    
    return grapheInit, grapheSansInit, listeBorneInf


def diagrammeTempsParNoeud():
    return 1
    
def diagrammeTempsInitialisation():
    nbTaches = 7 # Pas besoin d'en avoir beaucoup
    listeBorneSup = [10*i+4 for i in range(10)]
    grapheInit = []
    grapheSansInit = []
    
    for borne in listeBorneSup:
        listeInit = []
        listeSansInit = []
        for i in range(20):
            taches = creerTaches(i, 1, borne)
            agents = creerAgents(taches, 50)
            gInit = Graph(agents, 1, TrieDeuxADeux)
            gSansInit = Graph(agents, 0, TrieDeuxADeux)
            
            listeInit.append(gInit.dureeInitialisation)
            listeSansInit.append(gSansInit.dureeInitialisation)
            
        grapheInit.append(listeInit)
        grapheSansInit.append(listeSansInit)
    
    """ Affichage du graphe """
    # Les labels
    plt.title("Graphe représentant le temps d'initialisation selon la tâche de durée maximale")
    # Titres des axes
    plt.axes().set(xlabel='Durée maximale des tâches', ylabel="Temps d'initialisation")
    
    x= listeBorneSup
    yInit = [np.mean([noeud for noeud in listG]) for listG in grapheInit]
    ySansInit = [np.mean([noeud for noeud in listG]) for listG in grapheSansInit]

    plt.plot(x, yInit, color="red", label="Avec initialisation")
    plt.plot(x, ySansInit, color="blue", label="Sans initialisation")
    plt.legend()
    plt.show()
    

def diagrammeNoeudsVisiteEnFonctionBorneSup():
    
    nbTaches = 13
    listeBorneSup = [10*i+5 for i in range(5)]
    graphes = []
    for borne in listeBorneSup:
        liste = []
        for i in range(1):
            liste.append(creerGraph(nbTaches, borne).nbNoeuds)
        graphes.append(liste)
        
    """ Affichage du graphe """
    # Les labels
    plt.title("Graphe représentant le nombre de noeuds visités selon la tâche de durée maximale")
    # Titres des axes
    plt.axes().set(xlabel='Durée maximale des tâches', ylabel='Nombre de noeuds visités')
    
    x= listeBorneSup
    y = [np.mean([noeud for noeud in listG]) for listG in graphes]
    plt.scatter(x, y, s = 15)
    
    fit = np.polyfit(x, y, 1)
    poly = np.poly1d(fit)
    
    plt.plot(x, [poly(x0) for x0 in x], color="red")
    plt.show()
    
            

def grapheRechercheLocale(inf, sup):
    
    listTimeRL =[]
    listnbTachesRL=[]
    
    listTimeBB =[]
    listnbTachesBB=[]
    
    for i in range(inf,sup+1):
        agents = creerDonnees(i,100, 1, 15)[1]
        
        t1 =time.time()
        RechercheLocale(agents, 1, PositionalScoringRules, Tardiness)
        t2 =time.time()
        
        listnbTachesRL.append(i)
        listTimeRL.append(t2-t1)
        
        t1 =time.time()
        RechercheLocaleX(agents, 1, PositionalScoringRules, Tardiness)
        t2 =time.time()
        
        listnbTachesBB.append(i)
        listTimeBB.append(t2-t1)
        
        
    xRL=np.array(listnbTachesRL)
    yRL=np.array(listTimeRL)
    
    xBB=np.array(listnbTachesBB)
    yBB=np.array(listTimeBB)
    
    plt.plot(xRL,yRL,label="RL all", linewidth=2)
    plt.plot(xBB,yBB, label="RL 1er bon voisin", color='r')

    plt.xlabel("Nombre de taches")
    plt.ylabel("Temps (s)")
    plt.title("Recheche Locale (version choix du premier voisin vs visites des tous voisins)")
    plt.legend()
    plt.show()
    
    return
    
    
def condorcet(n):
    
    taches, agents = creerDonnees(n, 100, 5, 15)
    res =PTACopelandMethod(agents)[1]
    totalAgents=0
    for agent in agents:
        totalAgents+=agent.importance
    
    scores=[]
    
    for tache1 in taches :
        for tache2 in taches:
            scoreTache = 0
            if tache1 == tache2 :
                break   
            for agent in agents :
                for tacheAgent in agent.ordre:
                    if tacheAgent == tache2:
                            break
                    if tacheAgent == tache1:
                        scoreTache += agent.importance
                        break
            if scoreTache > totalAgents/2:
                scores.append([tache1, tache2, scoreTache])
                
    nbDiff = 0.0
    
    for score in scores:
        for tache in res:
            if score[0] == tache:
                break
            if score [1] == tache:
                nbDiff+=1
                
    return nbDiff/len(scores)
    

def moyenneCondorcet(n):
    res=0.0
    for i in range (1,50):
        res += condorcet(n)
    
    return res/50
        
    

            