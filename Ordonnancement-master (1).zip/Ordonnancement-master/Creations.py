# -*- coding: utf-8 -*-
try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *

from AffichageDonnees import *
"""
Classe implementant la fenetre de création de agent
"""
class CreationAgent(QDialog):
    
    """
    Si il s'agit d'une modification d'un agent, alors on prend cette agent en parametre
    """
    def __init__(self, parent, agent=None):
        print('init creation Agent')
        QDialog.__init__(self, parent)
        
        self.parent = parent
        self.interface = parent.interface
        self.agent = agent
        if self.agent is None:
            self.edit=False
        else:    
            self.edit = True
        self.setLayout(FormulaireAgent(self, agent))
    

class FormulaireAgent(QFormLayout):
    
    def __init__(self, parent, agent):
        QFormLayout.__init__(self)
        
        self.parent = parent
        self.agent = agent

        self.initVariable()
        self.initValeursPrincipale()
        self.initCouleurs()
        self.initOrdre()
        
        self.addRow(self.widgetPrincipale)
        self.addRow(self.widgetOrdonnancement)
        self.addRow(self.widgetCouleurs)
        
        self.accepter = QPushButton('Accepter')
        self.accepter.clicked.connect(self.send)
        self.annuler = QPushButton('Annuler')
        self.annuler.clicked.connect(self.fin)

        
        self.addRow(self.accepter, self.annuler)
    
    def initVariable(self):
        self.modif = True
        if not self.agent:
            self.modif = False
            self.agent = self.parent.interface.Global.agent('', 0)
        
        self.Fg = self.agent.couleurFg
        self.Bg = self.agent.couleurBg
        
        self.fromHexadecimalColor = self.parent.interface.Global.fonction['fromHexadecimalColor']
        self.hexadecimalColor =  self.parent.interface.Global.fonction['hexadecimalColor']
        
        fg = self.fromHexadecimalColor(self.Fg)
        bg = self.fromHexadecimalColor(self.Bg)
        self.couleurFg = QColor.fromRgb(fg[0], fg[1], fg[2])
        self.couleurBg = QColor.fromRgb(bg[0], bg[1], bg[2])

        self.font = self.agent.font
    
    def initValeursPrincipale(self):
        self.widgetPrincipale = QGroupBox('Valeurs')
        self.layoutPrincipale = QFormLayout()
        self.widgetPrincipale.setLayout(self.layoutPrincipale)
        
        self.nomLabel = QLabel('Nom')
        self.importanceLabel = QLabel('Importance')
        self.nom = QLineEdit()
        self.nom.setText(self.agent.nom)
        self.importance = QSpinBox()
        self.importance.setValue(self.agent.importance)
        
        self.layoutPrincipale.addRow(self.nomLabel, self.nom)
        self.layoutPrincipale.addRow(self.importanceLabel, self.importance)
        
    def initOrdre(self):        
        
        self.widgetOrdonnancement= QGroupBox('Ordonnancement')
        self.layoutForms = QHBoxLayout()
        self.widgetOrdonnancement.setLayout(self.layoutForms)
        
        self.comboBox = [QComboBox() for i in self.parent.interface.Global.taches]
        
        nbH = len(self.comboBox)//5 +1
        
        for i in range(nbH):
            if i!=0:
                q =QWidget()
                q.setFixedWidth(1)
                q.setStyleSheet("""
                            QWidget {border: 2px groove grey;}""")
                            
                self.layoutForms.addWidget(q)
                

            form = QFormLayout()
            for j in range(i*5,(i+1)*5,1):
                if j == len(self.comboBox):
                    break
                numero = QLabel(str(j+1))
                self.comboBox[j].addItem('')
                
                print(self.parent.edit)
                # Si il s'agit d'une modification alors toute les taches sont déjà ordonnée
                if not self.parent.edit:
                    for tache in self.parent.interface.Global.taches:
                            self.comboBox[j].addItem(tache.nom)
                else:
                    self.comboBox[j].addItem(self.agent.ordre[j].nom)
                    self.comboBox[j].setCurrentIndex(1)
                            
                self.comboBox[j].activated.connect(self.changeValueCB) 
 
                form.addRow(numero, self.comboBox[j])
            self.layoutForms.addLayout(form)
             

    def changeValueCB(self, t):
        tacheChoisi = []
        for combo in self.comboBox:
            t=str(combo.currentText())
            choose = False
            for tache in self.parent.interface.Global.taches:
                if t == tache.nom:
                    choose = True
                    break
            if choose:
                tacheChoisi.append(t)
                
        tacheNonChoisi = [tache.nom for tache in self.parent.interface.Global.taches if tache.nom not in tacheChoisi]
        for combo in self.comboBox:
            t=str(combo.currentText())
            if t == '':
                combo.clear()
                combo.addItem('')
                for nom in tacheNonChoisi:
                    combo.addItem(nom)
            else:
                
                combo.clear()
                combo.addItem('')
                combo.addItem(t)
                combo.setCurrentIndex(1)
                
                for nom in tacheNonChoisi:
                    combo.addItem(nom)
                
        
        print(tacheChoisi, tacheNonChoisi)
                    
                    
        
        
    def initCouleurs(self):
        
        self.widgetCouleurs = QGroupBox('Couleurs')
        self.layoutCouleurs = QFormLayout()

        self.widgetCouleurs.setLayout(self.layoutCouleurs)
        
        self.couleurBgLabel = QLabel("Couleur du background")
        self.couleurFgLabel = QLabel("Couleur de la police")
        self.policeLabel = QLabel("Police du texte")
        
        self.couleurWBg = QPushButton('Couleur')
        self.couleurWFg = QPushButton('couleur')
        self.police = QPushButton('police')
        
        #self.police.clicked.connect(self.on_click)
        self.police.clicked.connect(self.policeDialog)
        self.couleurWFg.clicked.connect(self.colorBackground)
        self.couleurWBg.clicked.connect(self.colorForeground)
        
        self.layoutCouleurs.addRow(self.policeLabel, self. police)
        self.layoutCouleurs.addRow(self.couleurBgLabel, self.couleurWBg)
        self.layoutCouleurs.addRow(self.couleurFgLabel, self.couleurWFg)
                
   
    def policeDialog(self):
        self.font, ok = QFontDialog.getFont(self.font)
        

    
    def colorBackground(self):
        dialog = QColorDialog()
        self.couleurBg = dialog.getColor()
        red, green, blue, alpha = self.couleurBg.getRgb()
        self.Bg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)

    def colorForeground(self):
        dialog = QColorDialog()
        self.couleurFg = dialog.getColor()
        red, green, blue, alpha = self.couleurFg.getRgb()
        self.Fg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)
        
    
    def send(self):
        dic = { 'nom':str(self.nom.text()),
                'importance':int(self.importance.text())}
        
        
        dic['couleurFg']=self.Fg
        dic['couleurBg']=self.Bg
        dic ['ordre']=[str(combo.currentText()) for combo in self.comboBox]
        dic['font']= self.font
         
        if self.modif:
            boolean, res = self.parent.interface.Global.modifierAgent(self.agent, dic)
        else:
            boolean, res = self.parent.interface.Global.ajouterAgent(dic)
        
        
        if boolean:
            print(dic)
            # Si il s'agit de modification alors on change la représentation
            if self.parent.edit:
                self.parent.parent.modAgentWidget(0)
            self.fin(1)
        else:
            print(res)
            
    
    def fin(self, done=0):
        self.parent.done(done)
        
"""
Modifier les agents
"""
class ModifierAgent(QDialog):
    def __init__(self, interface):
        QDialog.__init__(self, interface)
        self.interface= interface
        self.layout = QVBoxLayout()
        
        self.rechercheLayout= QHBoxLayout()
        self.rechercheLabel = QLabel("Nom de l'agent")
        self.rechercheEdit = QLineEdit()
        self.rechercheButton = QPushButton("Rechercher")
        self.rechercheButton.clicked.connect(self.recherche)
        
        self.quitter = QPushButton("Quitter")
        self.quitter.clicked.connect(self.fin)
        
        self.rechercheLayout.addWidget(self.rechercheLabel)        
        self.rechercheLayout.addWidget(self.rechercheEdit)
        self.rechercheLayout.addWidget(self.rechercheButton)
        self.rechercheLayout.addWidget(self.quitter)
        self.layout.addItem(self.rechercheLayout)        

        
        self.scrollArea = QScrollArea()
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        
        self.layout.addWidget(self.scrollArea)
        self.widgetIn =QWidget()
        self.widgetIn.setStyleSheet("""
                            .QWidget{
                            background:#a16947}
                            """)

        
        self.listAgentWidget = [self.interface.Global.pyqt['WidgetAgent'](self, agent) for agent in self.interface.Global.agents]
        
        self.mainLayout = QVBoxLayout()
        self.mainLayout.setAlignment(Qt.AlignTop)
        
        self.rechercherLayout = QHBoxLayout()
        
        self.rechercherLabel = QLabel("Nom de l'agent à modifier")
        self.rechercherEdit = QLineEdit()
        
        self.rechercherLayout.addWidget(self.rechercherLabel)
        self.rechercherLayout.addWidget(self.rechercherEdit)
        
        for ag in self.listAgentWidget:
            self.mainLayout.addWidget(ag)

        
        
        self.widgetIn.setLayout(self.mainLayout)
        self.scrollArea.setWidget(self.widgetIn)
        self.setLayout(self.layout)
    
    def recherche(self):
        taille = len(self.rechercheEdit.text())
        if not taille:
            for ag in self.listAgentWidget:
                ag.show()
            return
        for ag in self.listAgentWidget:
            
            if self.rechercheEdit.text()[-1] == ".":
                if ag.agent.nom== self.rechercheEdit.text()[:taille-1]:
                    ag.show()
                else:
                    ag.hide()
            else:
                if ag.agent.nom[:taille] == self.rechercheEdit.text():
                    ag.show()
                else:
                    ag.hide()
    
    
    """
    Probleme de stylesheet avec les classes personnalisées
    """
    def paintEvent(self, paintEvent):
        opt = QStyleOption()
        opt.initFrom(self)
        p= QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        QWidget.paintEvent(self, paintEvent)
        
    """
    """
    def fin(self):
        self.done(1)
        
"""
Classe implementant la fenetre de création de tache
"""
class CreationTache(QDialog):
    
    """
    Si il s'agit d'une modification de tache, alors on prend cette tache en parametre
    """
    def __init__(self, interface, tache=None):
        print('init creation tache')
        QDialog.__init__(self, interface)

        self.interface = interface
        self.tache = tache

        self.setLayout(FormulaireTache(self))
    

class FormulaireTache(QFormLayout):
    
    def __init__(self, parent):
        QFormLayout.__init__(self)
        
        self.parent = parent
        self.tache = self.parent.tache
        
        
        self.fromHexadecimalColor = self.parent.interface.Global.fonction['fromHexadecimalColor']
        self.hexadecimalColor =  self.parent.interface.Global.fonction['hexadecimalColor']
        
        self.initVariable()
        self.initValeursPrincipale()
        self.initCouleurs()
        
        self.addRow(self.widgetPrincipale)
        self.addRow(self.widgetCouleurs)
        
        self.accepter = QPushButton('Accepter')
        self.accepter.clicked.connect(self.send)
        self.annuler = QPushButton('Annuler')
        self.annuler.clicked.connect(self.fin)

        
        self.addRow(self.accepter, self.annuler)
    
    def initVariable(self):
        self.modif = True
        if not self.tache:
            self.modif = False
            self.tache = self.parent.interface.Global.tache('', 0)
        
        self.Fg = self.tache.couleurFg
        self.Bg = self.tache.couleurBg
        fg = self.fromHexadecimalColor(self.Fg)
        bg = self.fromHexadecimalColor(self.Bg)
        self.couleurFg = QColor.fromRgb(fg[0], fg[1], fg[2])
        self.couleurBg = QColor.fromRgb(bg[0], bg[1], bg[2])

        self.font = self.tache.font
    
    def initValeursPrincipale(self):
        self.widgetPrincipale = QGroupBox('Valeurs')
        self.layoutPrincipale = QFormLayout()
        self.widgetPrincipale.setLayout(self.layoutPrincipale)
        
        self.nomLabel = QLabel('Nom')
        self.dureeLabel = QLabel('Duree')
        self.nom = QLineEdit()
        self.nom.setText(self.tache.nom)
        self.duree = QSpinBox()
        self.duree.setValue(self.tache.duree)
        
        self.layoutPrincipale.addRow(self.nomLabel, self.nom)
        self.layoutPrincipale.addRow(self.dureeLabel, self.duree)
        
        
    def initCouleurs(self):
        
        self.widgetCouleurs = QGroupBox('Couleurs')
        self.layoutCouleurs = QFormLayout()
        self.widgetCouleurs.setLayout(self.layoutCouleurs)
        
        self.couleurBgLabel = QLabel('Couleur du background')
        self.couleurFgLabel = QLabel('Couleur de la police')
        self.policeLabel = QLabel('Police')
        
        self.couleurWBg = QPushButton('Couleur')
        self.couleurWFg = QPushButton('couleur')
        self.police = QPushButton('police')
        
        #self.police.clicked.connect(self.on_click)
        self.police.clicked.connect(self.policeDialog)
        self.couleurWBg.clicked.connect(self.colorBackground)
        self.couleurWFg.clicked.connect(self.colorForeground)
        
        self.layoutCouleurs.addRow(self.couleurBgLabel, self.couleurWBg)
        self.layoutCouleurs.addRow(self.couleurFgLabel, self.couleurWFg)
        self.layoutCouleurs.addRow(self.policeLabel, self. police)
        
   
    def policeDialog(self):
        self.font, ok = QFontDialog.getFont(self.font)
        

    
    def colorBackground(self):
        dialog = QColorDialog()
        self.couleurBg = dialog.getColor()
        red, green, blue, alpha = self.couleurBg.getRgb()
        self.Bg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)

    def colorForeground(self):
        dialog = QColorDialog()
        self.couleurFg = dialog.getColor()
        red, green, blue, alpha = self.couleurFg.getRgb()
        self.Fg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)
        
    
    def send(self):
        dic = { 'nom':str(self.nom.text()),
                'duree':int(self.duree.text())}
        
        
        dic['couleurFg']=self.Fg
        dic['couleurBg']=self.Bg
        
        dic['font']= self.font
         
        if self.modif:
            boolean, res = self.parent.interface.Global.modifierTache(self.tache, dic)
        else:
            boolean, res = self.parent.interface.Global.ajouterTache(dic)
        
        
        if boolean:
            print(dic)
            self.parent.interface.initTaches()
            self.fin(1)
        else:
            print(res)
            
    
    def fin(self, done=0):
        self.parent.done(done)
        
        
        
        
        
        
        
        
        
        
        