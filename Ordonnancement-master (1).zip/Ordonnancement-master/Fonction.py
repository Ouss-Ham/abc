# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 15:11:00 2018

@author: 3415104
"""

      
"""
Retourne une chaine de caractère
"""        
def hexadecimalColor(number):
    a = number %16
    b = number // 16
    chaine=''
    if b < 10:
        chaine+=str(b)
    if b == 10:
        chaine+='A'
    if b == 11:
        chaine+='B'
    if b == 12:
        chaine+='C'
    if b == 13:
        chaine+='D'
    if b == 14:
        chaine+='E'
    if b == 15:
        chaine+='F'
        
    if a < 10:
        chaine+=str(a)
    if a == 10:
        chaine+='A'
    if a == 11:
        chaine+='B'
    if a == 12:
        chaine+='C'
    if a == 13:
        chaine+='D'
    if a == 14:
        chaine+='E'
    if a == 15:
        chaine+='F'
    return chaine
    
    
"""
Retourne triplet d'entier
"""      
def fromHexadecimalColor(chaine):
    a, r1, r2, g1, g2, b1, b2 = chaine
    
    l = [r1, r2, g1, g2, b1, b2]
    print(l)
    for i in range(len(l)):
        if l[i] == 'A' or l[i] == 'a':
            l[i] = 10
        if l[i] == 'B' or l[i] == 'b':
            l[i] = 11
        if l[i] == 'C' or l[i] == 'c':
            l[i] = 12
        if l[i] == 'D' or l[i] == 'd':
            l[i] = 13
        if l[i] == 'E' or l[i] == 'e':
            l[i] = 14
        if l[i] == 'F' or l[i] == 'f':
            l[i] = 15
    l = [int(i) for i in l]
    print(l)
    return l[0]*16+l[1], l[2]*16+l[3], l[4]*16+l[5]
    
"""
Trouver un objet dans une liste avec son nom
"""  
def findObjectByNameInList(liste, nom):
    for obj in liste:
        if obj.nom == nom:
            return obj
    return None



def Tardiness(t1,t2):
    if t1-t2>0:
        return t1 - t2
    else:
        return 0
        
def UnitPenalties(t1,t2):
    if t1-t2>0:
        return 1
    else:
        return 0
        
def Lateness(t1,t2):
    return t1 - t2

def Earliness(t1,t2):
    if t1-t2<0:
        return t1 - t2
    else:
        return 0

def AbsoluteDeviation(t1,t2):
    return abs(t1 - t2)

def SquaredDeviation(t1,t2):
    return (t1 - t2)**2


"""
Retourne le cout d'un ordonnancement selon la methode voulut
"""
def cost(agents, ordonnancement, fonction):
    fin = 0
    cout = 0
    for t in ordonnancement:
        fin += t.duree
        for ag in agents:
            cout+= fonction(fin, ag.finTache[t])*ag.importance
    return cout
        