# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 12:49:32 2018

@author: 3415104
"""

from time import time
class root():
    
    def __init__(self, taches, agents, method='PTA'):
        t = time()
        
        self.nom = 'Branch and Bound minimisant le retard'
        self.taches =taches
        self.agents = agents
        self.method = method
        self.temps = sum([tache.duree for tache in self.taches])
        self.nbNoeuds = 0
        self.valOpti = []
        self.firstOrd()
        
        Noeud(self, [])
        
        self.duree = time() - t
        
        
    def firstOrd(self):
        if self.method == 'PTA':
            print('PTA')
            ordonnancement = self.PTACopelandMethod([])
        elif self.method == '':
            print('ORDRE')
            ordonnancement = [tache for tache in self.taches]
        else:
            print('TRIE')
            ordonnancement = self.trieTaches([])
        retard = self.classicalLateMethod(ordonnancement)
        self.changeOptimum(retard, ordonnancement)

    def classicalLateMethod(self, ordonnancement):
        retard = 0
        finOrd = self.temps
        for tache in ordonnancement:
            
            for agent in self.agents:
                finAgent = agent.finTache[tache]
                if finOrd - finAgent > 0:
                     retard += (finOrd - finAgent) * agent.importance
            
            finOrd-=tache.duree
        return retard
    
    def LateMethod(self, ordonnancement):
        retard = 0
        finOrd = 0
        for tache in ordonnancement:
            finOrd+=tache.duree
            for agent in self.agents:
                finAgent = agent.finTache[tache]
                if finOrd - finAgent > 0:
                     retard += (finOrd - finAgent) * agent.importance
        return retard
        
    def trieTaches(self,ordonnancement):
        taches = self.taches
        agents = self.agents
        ordre = [t for t in taches]
        dejaOrd = []
        
        while len(dejaOrd)<len(ordre):
            indice = 0
            tache = ''
            for i in range(len(ordre)):
                if ordre[i] not in dejaOrd:
                    indice = i
                    tache= ordre[i]
                    break
            valeurLate = self.RETARD(agents, ordre)
            for i in range(indice,len(ordre)-1):
                newOrd = [t for t in ordre]
                newOrd[i], newOrd[i+1]=newOrd[i+1], newOrd[i]
                newValeur = self.RETARD(agents, newOrd)
                if newValeur <= valeurLate:
                    ordre = [t for t in newOrd]
                    valeurLate = newValeur
            
            dejaOrd.append(tache)
        ordre.reverse()
        return ordre
    """
    Renversé
    """
    def PTACopelandMethod(self, ordonnancement):
        
        agents =self.agents
        taches = [t for t in self.taches if t not in ordonnancement]
        f_score = [[0, tache] for tache in taches]
        
        
        for i in range(len(taches)):
            for tache in taches:
                
                if tache != taches[i]:
                    coeff = (taches[i].duree*1.0 /(taches[i].duree*1.0 + tache.duree*1.0)) * len(agents)
                    coeff = int(coeff)
                    
                    nbAgent = 0
                    for agent in agents:
                        for tacheAgent in agent.ordre:
                            if tacheAgent == tache:
                                break
                            if tacheAgent == taches[i]:
                                nbAgent += agent.importance
                                
                    if nbAgent > coeff:
                       f_score[i][0]+=1
   
        sort = sorted(f_score, key=lambda colonnes: colonnes[0])
        sort
        return ordonnancement+[tache[1] for tache in sort]   
        
        
    def description(self):
        s = ""
        s+="Le temps d'execution de c'est algorithme est de "+str(self.duree)+" secondes"
        s+="\nL'algorithme a visite "+str(self.nbNoeuds)+" sur "+str(self.nbPossibleNoeuds(len(self.taches)))+" & proportion="+str(float(self.nbNoeuds)/float(self.nbPossibleNoeuds(len(self.taches))))
        s+="\nLe retard est de "+str(self.late)
        return s
    
    
    def changeOptimum(self, retard, ordonnancement):
        self.late = retard
        self.ordonnancement = ordonnancement
        late = self.LateMethod(self.ordonnancement)
        print('1',self.late)
        a = [t for t in ordonnancement]
        a.reverse()
        print('2', self.RETARD(self.agents, a))
        self.valOpti.append(self.late)
    
    """
    Nombre de noeuds potentiel
    """
    def nbPossibleNoeuds(self, n):
        if n==0:
            return 1
        else:
            return n*self.nbPossibleNoeuds(n-1) + 1
       
       
    """
    Retard d'un ordonnacements
    """
    def RETARD(self, agents, ordonnancement):
        retard = 0
        fin = 0
        for tache in ordonnancement:
            fin+=tache.duree
            for agent in agents:
                finT = agent.finTache[tache]
                if fin - finT > 0:
                    retard+= (fin - finT)* agent.importance
        return retard

class Noeud():
    def __init__(self, root, ordonnancement):
        self.root = root
        self.ordonnancement = ordonnancement
        self.root.nbNoeuds+=1

        if len(ordonnancement) == len(self.root.taches):
            retard = self.root.classicalLateMethod(self.ordonnancement)
            if retard < self.root.late:
                self.root.changeOptimum(retard, ordonnancement)
                return

        dic={}
        for tache in [tache for tache in self.root.taches if tache not in self.ordonnancement]:
            dic[tache] = [self.borneInf(tache), self.borneSup(tache)]
            
        l = [[t, value[0]] for t, value in dic.items()]
        l=sorted(l, key=lambda colonnes: colonnes[1])
        for v in l:
            tache = v[0]
            
            # Si la borne sup est inférieur au résultat alors
            if self.root.late > dic[tache][1]:
                self.root.ordonnancement = self.root.PTACopelandMethod(self.ordonnancement+[tache])
                self.root.late = self.root.classicalLateMethod(self.root.ordonnancement)
                
            if not dic[tache][0] >= self.root.late:
                Noeud(self.root, [t for t in self.ordonnancement]+[tache])
    
    
    """
    Borne inf des noeuds fils
    """
    def borneInf(self, tache):
        ord = [t for t in self.ordonnancement]+[tache]
        retard = self.root.classicalLateMethod(ord)
        return retard
    
    """
    Borne sup des noeuds fils
    """
    def borneSup(self, tache):
        ord = [t for t in self.ordonnancement]+[tache]
        for t in self.root.taches:
            if t not in ord:
                ord.append(t)
        return self.root.classicalLateMethod(ord)


       
