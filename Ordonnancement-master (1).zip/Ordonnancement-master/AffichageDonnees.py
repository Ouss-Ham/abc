# encoding=utf8  
try:
    from PyQt5.QtCore import *
    from PyQt5.QtGui import *
    from PyQt5.QtWidgets import *
except:
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *

from Fonction import *
"""
Qwidget instantiant le design d'une tâche
@param parent : parent du widget
@param tache : tache à afficher
@param modification : boolean permettant la modification ou non de la tache
"""
class WidgetTache(QWidget):
    def __init__(self, parent, tache, modification=True):
        QWidget.__init__(self)
        self.tache = tache
        self.parent=parent
        self.modification = modification
        
        police = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        #police.setHorizontalStretch(tache.duree)
        self.setSizePolicy(police)
        
        self.setStyleSheet("""
                            QWidget {border: 2px groove """+tache.couleurBg+""";
                                    background: """+tache.couleurBg+""";
                                    color: """+tache.couleurFg+""";
                                    border-radius: 5px;}
                            QLabel {border: 0px solid red;}
                            """)
                            
        layout = QVBoxLayout()        
        nom = QLabel(tache.nom)
        duree = QLabel(str(tache.duree))
        
        nom.setFont(tache.font)
        duree.setFont(tache.font)
        nom.setAlignment(Qt.AlignHCenter)
        duree.setAlignment(Qt.AlignHCenter)
        
        layout.addWidget(nom)
        layout.addWidget(duree)
        
        self.setLayout(layout)

    """
    Probleme de stylesheet avec les classes personnalisées
    """
    def paintEvent(self, paintEvent):
        opt = QStyleOption()
        opt.initFrom(self)
        p= QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        QWidget.paintEvent(self, paintEvent)
        
    """
    Modification de la tache lorsqu'on clique dessus
    """
    def mousePressEvent(self, event):
        if self.modification:
            dialog = self.parent.interface.Global.pyqt['CreationTache'](self.parent.interface, self.tache)
            dialog.show()

"""
Qwidget instantiant le design d'un agent
@param parent : parent du widget
@param agent : agent à afficher
"""
class WidgetAgent(QWidget):
    def __init__(self, parent, agent):
        QWidget.__init__(self)
        
        self.agent = agent
        self.parent=parent
        self.interface = parent.interface
        self.setStyleSheet("""
                            QWidget[class~="WidgetAgent"] {border: 1px groove black;
                                    background-color:#FFD0A0;}
                            QLabel {border: 1px solid """+agent.couleurBg+""";
                                    background-color: """+agent.couleurBg+""";
                                    color: """+agent.couleurFg+""";
                                    border-radius: 5px;}
                            """)
                            
        police = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setSizePolicy(police)
        
        self.modAgentWidget()        
        self.setLayout(self.layout)
    
    def modAgentWidget(self, init=1):
        if not init:
            for t in self.taches:
                self.layout.removeWidget(t)
                t.deleteLater()
                
            self.layout.removeWidget(self.nom)
            self.nom.deleteLater()
            self.nom =QLabel(self.agent.nom, self)
            self.nom.setAlignment(Qt.AlignCenter)
            self.nom.setFont(self.agent.font)
            self.nom.setToolTip(str(self.agent.importance))
            sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self.nom.setSizePolicy(sizePolicy)
            
            self.layout.addWidget(self.nom)
            
            self.taches = []
            for tache in self.agent.ordre:
                t = self.parent.interface.Global.pyqt['WidgetTache'](self, tache, modification=False)
                self.taches.append(t)
                self.layout.addWidget(t)# Affiche les tâches sans qu'elles puissent être modifié par un clique
            
        else:
            self.taches = []
            self.layout = QHBoxLayout()           
            self.layout.setAlignment(Qt.AlignLeft) # Aligne les élements d'un agent à gauche
            
            self.nom =QLabel(self.agent.nom, self)
            self.nom.setAlignment(Qt.AlignCenter)
            self.nom.setFont(self.agent.font)
            self.nom.setToolTip(str(self.agent.importance))
            sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self.nom.setSizePolicy(sizePolicy)
            
            self.layout.addWidget(self.nom)
            for tache in self.agent.ordre:
                t = self.parent.interface.Global.pyqt['WidgetTache'](self, tache, modification=False)
                self.taches.append(t)
                self.layout.addWidget(t)# Affiche les tâches sans qu'elles puissent être modifié par un clique


    """
    Probleme de stylesheet avec les classes personnalisées
    """
    def paintEvent(self, paintEvent):
        opt = QStyleOption()
        opt.initFrom(self)
        p= QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        QWidget.paintEvent(self, paintEvent)
        
    
    def mousePressEvent(self, event):
        dialog = self.parent.interface.Global.pyqt['CreationAgent'](self, self.agent)
        dialog.show()


"""
QPushButton d'un algorithm d'ordonnancement
@param parent : parent du widget
@param algo : fonction retournant l'ordonnacement optimal selon cette algorithme
"""
class ButtonAlgo(QWidget):
    def __init__(self, parent, algo):
        QWidget.__init__(self)
        self.setStyleSheet("""QWidget[class~="ButtonAlgo"] 
        
                                        {background-color:#a16947;
                                        border:10px solid #a16947;
                                        border-radius: 10px;}
                            """)
 

        self.mainLayout = QVBoxLayout()

        self.mainLayout.setAlignment(Qt.AlignTop)        
        
        self.hLayout = QHBoxLayout()
        self.hLayout.setAlignment(Qt.AlignCenter)
        self.description = QTextEdit(algo.description)
        
        font = self.description.document().defaultFont()    # or another font if you change it
        fontMetrics = QFontMetrics(font)      # a QFontMetrics based on our font
        textSize = fontMetrics.size(0, algo.description)
        self.description.setMaximumHeight(textSize.height()+35)

        self.description.setReadOnly(True)
        
        self.mainLayout.addLayout(self.hLayout)
        self.mainLayout.addWidget(self.description)
        self.setLayout(self.mainLayout)
        
        self.algo = algo
        self.parent = parent
        
        self.nom = QLabel(algo.nom)
        self.button = QPushButton("Lancer")
        self.hLayout.addWidget(self.nom)
        self.hLayout.addWidget(self.button)

        self.mainLayout.addStretch(0)
        
        self.button.clicked.connect(self.on_click)
        

    """
    Fonction débutant lorsque le bouton est activé. La fonction commence l'algorithme
    """
    def on_click(self):
        res = self.algo.fonction(self.parent.interface.Global.agents)
        self.parent.interface.resultat.ajouterResultat(res, self.algo.nom)
        self.parent.interface.tabWidget.setCurrentIndex(1)
        
    """
    Probleme de stylesheet avec les classes personnalisées
    """
    def paintEvent(self, paintEvent):
        opt = QStyleOption()
        opt.initFrom(self)
        p= QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        QWidget.paintEvent(self, paintEvent)

        
        

class BranchAndBoundWidget(QGroupBox):
    def __init__(self, parent):
        QGroupBox.__init__(self)        
        self.setStyleSheet("""QGroupBox{background-color:#FFD0A0;
                                        border:10px solid #FFD0A0;}
                            """)
        
        self.mainLayout = QGridLayout()
        
        self.parent = parent
        
        self.labelTypeAlgo = QLabel("Algorithme utiliser :")
        self.labelFonctionObjectif = QLabel("Fonction objectif : ")
        self.labelAlgoInit = QLabel("Algorithme initial : ")
        self.labelValeurInit = QLabel("Initialiser les valeurs en premier ? ")
        
        self.editTypeAlgo = self.typeAlgo()
        self.editFonctionObjectif = self.objectif()
        self.editAlgoInit = self.init()
        self.editValeurInit = QRadioButton()
        
        self.mainLayout.addWidget(self.labelTypeAlgo, 1,1)
        self.mainLayout.addWidget(self.labelFonctionObjectif, 2,1)
        self.mainLayout.addWidget(self.labelAlgoInit, 3,1)
        self.mainLayout.addWidget(self.labelValeurInit, 4,1)
        
        self.mainLayout.addWidget(self.editTypeAlgo, 1,2)
        self.mainLayout.addWidget(self.editFonctionObjectif, 2,2)
        self.mainLayout.addWidget(self.editAlgoInit, 3,2)
        self.mainLayout.addWidget(self.editValeurInit, 4,2)
        
        
        
        self.description = QTextEdit()
        text = "L'algorithme de brand and bound renvoit un ordonnancement optimal selon la fonction objectif."+"\n"+"La fonction objectif est la fonction qui calcul le retard des tâches dans un ordonnancement."
        self.description.setPlainText(text)
        self.mainLayout.addWidget(self.description, 1,4, 4,3)
        
        self.labelTemps = QLabel("Durée maximale(en s)")
        self.editTemps = QSpinBox()
        
        self.editTemps.setValue(300)
        
        self.mainLayout.addWidget(self.labelTemps, 1,7, 1,1)
        self.mainLayout.addWidget(self.editTemps, 2,7, 1,1)
        
        self.lancer = QPushButton("Lancer")
        self.lancer.clicked.connect(self.onClick)
        self.mainLayout.addWidget(self.lancer, 3,7, 1,1)
        
        self.setLayout(self.mainLayout)

        
        
    def onClick(self):
        
        agents = self.parent.interface.Global.agents
        calculValeursInitialement = self.editValeurInit.isChecked()
        methodInit = self.parent.interface.Global.algorithmsRapide[self.editAlgoInit.currentText()].fonction
        fonction = self.parent.interface.Global.objectifs[self.editFonctionObjectif.currentText()]
        temps = self.editTemps.value()
        algoClass = self.parent.interface.Global.typeAlgo[self.editTypeAlgo.currentText()]
        
        bab = algoClass(agents, calculValeursInitialement, methodInit, fonction, temps)
        res = "", bab.getOrdonnancement(), None
        self.parent.interface.resultat.ajouterResultat(res, self.editFonctionObjectif.currentText())
        self.parent.interface.tabWidget.setCurrentIndex(1)
        
    def objectif(self):
        box = QComboBox()
        for key in self.parent.interface.Global.objectifs.keys():
            box.addItem(key)
        box.setCurrentIndex(0)
        return box
    
    def typeAlgo(self):
        box = QComboBox()
        for key in self.parent.interface.Global.typeAlgo.keys():
            box.addItem(key)
        box.setCurrentIndex(0)
        return box
        
    def init(self):
        box = QComboBox()
        for key in self.parent.interface.Global.algorithmsRapide.keys():
            box.addItem(key)
        box.setCurrentIndex(0)
        return box
    
    def changeDescription(self):
        desc = ""
        if self.editAlgoInit.currentText() == "BrandAndBound":
            desc+= "L'algorithme de brand and bound renvoit un ordonnancement optimal selon la fonction objectif"
        else:
            desc+= "L'algorithme de brand and bound renvoit un ordonnancement approché selon la fonction objectif"
        desc+="\n"
        if self.editFonctionObjectif.currentText()=="Tardiness":
            "La fonction objectif est la fonction qui calcul le retard des tâches dans un ordonnancement"
            
        elif self.editFonctionObjectif.currentText()=="UnitPenalties":
            "La fonction objectif est la fonction qui calcul le nombre de tâches en retard dans un ordonnancement"
            
        elif self.editFonctionObjectif.currentText()=="Lateness":
            "La fonction objectif est la fonction qui calcul l'écart des tâches dans un ordonnancement (bonus si la tâche est en avance"
            
        elif self.editFonctionObjectif.currentText()=="Earliness":
            "La fonction objectif est la fonction qui calcul l'avance des tâches dans un ordonnancement"
            
        elif self.editFonctionObjectif.currentText()=="AbsoluteDeviation":
            "La fonction objectif est la fonction qui calcul l'écart absolu des tâches dans un ordonnancement"
            
        elif self.editFonctionObjectif.currentText()=="SquareDeviation":
            "La fonction objectif est la fonction qui calcul le carrée de l'écart des tâches dans un ordonnancement"
    
    """
    Probleme de stylesheet avec les classes personnalisées
    """
    def paintEvent(self, paintEvent):
        opt = QStyleOption()
        opt.initFrom(self)
        p= QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        QWidget.paintEvent(self, paintEvent)