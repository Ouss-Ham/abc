# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 18:08:36 2018

@author: 3415104
"""

import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from Donnees import *
from time import time
"""
Classe implementant la fenetre de création de tache
"""
class CreationAgent(QDialog):
    
    """
    Si il s'agit d'une modification de tache, alors on prend cette tache en parametre
    """
    def __init__(self, interface, agent=None):
        print('init creation tache')
        QDialog.__init__(self, interface)

        self.interface = interface
        self.agent = agent
        
        self.setLayout(FormulaireAgent(self, agent))
    

class FormulaireAgent(QFormLayout):
    
    def __init__(self, parent, agent):
        QFormLayout.__init__(self)
        
        self.parent = parent
        self.agent = agent
        
        self.t = time()
        self.initVariable()
        self.initValeursPrincipale()
        self.initCouleurs()
        self.initOrdre()
        
        self.addRow(self.widgetPrincipale)
        self.addRow(self.widgetOrdonnancement)
        self.addRow(self.widgetCouleurs)
        
        self.accepter = QPushButton('Accepter')
        self.connect(self.accepter,SIGNAL("clicked()"),self.send)
        self.annuler = QPushButton('Annuler')
        self.connect(self.annuler,SIGNAL("clicked()"),self.fin)

        
        self.addRow(self.accepter, self.annuler)
    
    def initVariable(self):
        self.modif = True
        if not self.agent:
            self.modif = False
            self.agent = self.parent.interface.Global.agent('', 0)
        
        self.Fg = self.agent.couleurFg
        self.Bg = self.agent.couleurBg
        
        self.fromHexadecimalColor = self.parent.interface.Global.fonction['fromHexadecimalColor']
        self.hexadecimalColor =  self.parent.interface.Global.fonction['hexadecimalColor']
        
        fg = self.fromHexadecimalColor(self.Fg)
        bg = self.fromHexadecimalColor(self.Bg)
        self.couleurFg = QColor.fromRgb(fg[0], fg[1], fg[2])
        self.couleurBg = QColor.fromRgb(bg[0], bg[1], bg[2])

        self.font = self.agent.font
    
    def initValeursPrincipale(self):
        self.widgetPrincipale = QGroupBox('Valeurs')
        self.layoutPrincipale = QFormLayout()
        self.widgetPrincipale.setLayout(self.layoutPrincipale)
        
        self.nomLabel = QLabel('Nom')
        self.importanceLabel = QLabel('Importance')
        self.nom = QLineEdit()
        self.nom.setText(self.agent.nom)
        self.importance = QSpinBox()
        self.importance.setValue(self.agent.importance)
        
        self.layoutPrincipale.addRow(self.nomLabel, self.nom)
        self.layoutPrincipale.addRow(self.importanceLabel, self.importance)
        
    def initOrdre(self):        
        
        self.widgetOrdonnancement= QGroupBox('Ordonnancement')
        self.layoutForms = QHBoxLayout()
        self.widgetOrdonnancement.setLayout(self.layoutForms)
        
        self.listeOrdonnancement = ['' for i in self.parent.interface.Global.taches]
        self.comboBox = [QComboBox() for i in self.listeOrdonnancement]
        
        nbH = len(self.listeOrdonnancement)//5 +1
        
        for i in range(nbH):
            if i!=0:
                q =QWidget()
                q.setFixedWidth(1)
                q.setStyleSheet("""
                            QWidget {border: 2px groove grey;}""")
                            
                self.layoutForms.addWidget(q)
                

            form = QFormLayout()
            for j in range(i*5,(i+1)*5,1):
                if j == len(self.comboBox):
                    break
                numero = QLabel(str(j+1))
                self.comboBox[j].addItem('')
                for tache in self.parent.interface.Global.taches:
                        self.comboBox[j].addItem(tache.nom)
                self.comboBox[j].activated.connect(self.changeValueCB) 
 
                form.addRow(numero, self.comboBox[j])
            self.layoutForms.addLayout(form)
             

    def changeValueCB(self, t):
        tacheChoisi = []
        for combo in self.comboBox:
            t=str(combo.currentText())
            choose = False
            for tache in self.parent.interface.Global.taches:
                if t == tache.nom:
                    choose = True
                    break
            if choose:
                tacheChoisi.append(t)
                
        tacheNonChoisi = [tache.nom for tache in self.parent.interface.Global.taches if tache.nom not in tacheChoisi]
        for combo in self.comboBox:
            t=str(combo.currentText())
            if t == '':
                combo.clear()
                combo.addItem('')
                for nom in tacheNonChoisi:
                    combo.addItem(nom)
            else:
                
                combo.clear()
                combo.addItem('')
                combo.addItem(t)
                combo.setCurrentIndex(1)
                
                for nom in tacheNonChoisi:
                    combo.addItem(nom)
                
        
        print(tacheChoisi, tacheNonChoisi)
                    
                    
        
        
    def initCouleurs(self):
        
        self.widgetCouleurs = QGroupBox('Couleurs')
        self.layoutCouleurs = QFormLayout()

        self.widgetCouleurs.setLayout(self.layoutCouleurs)
        
        self.couleurBgLabel = QLabel("Couleur du background")
        self.couleurFgLabel = QLabel("Couleur de la police")
        self.policeLabel = QLabel("Police du texte")
        
        self.couleurWBg = QPushButton('Couleur')
        self.couleurWFg = QPushButton('couleur')
        self.police = QPushButton('police')
        
        #self.police.clicked.connect(self.on_click)
        self.connect(self.police,SIGNAL("clicked()"),self.policeDialog)
        self.connect(self.couleurWBg,SIGNAL("clicked()"),self.colorBackground)
        self.connect(self.couleurWFg,SIGNAL("clicked()"),self.colorForeground)
        
        self.layoutCouleurs.addRow(self.policeLabel, self. police)
        self.layoutCouleurs.addRow(self.couleurBgLabel, self.couleurWBg)
        self.layoutCouleurs.addRow(self.couleurFgLabel, self.couleurWFg)
                
   
    def policeDialog(self):
        self.font, ok = QFontDialog.getFont(self.font)
        

    
    def colorBackground(self):
        dialog = QColorDialog()
        self.couleurBg = dialog.getColor()
        red, green, blue, alpha = self.couleurBg.getRgb()
        self.Bg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)

    def colorForeground(self):
        dialog = QColorDialog()
        self.couleurFg = dialog.getColor()
        red, green, blue, alpha = self.couleurFg.getRgb()
        self.Fg = '#'+self.hexadecimalColor(red)+self.hexadecimalColor(green)+self.hexadecimalColor(blue)
        
    
    def send(self):
        dic = { 'nom':str(self.nom.text()),
                'importance':int(self.importance.text())}
        
        
        dic['couleurFg']=self.Fg
        dic['couleurBg']=self.Bg
        dic ['ordre']=self.listeOrdonnancement
        dic['font']= self.font
         
        if self.modif:
            boolean, res = self.parent.interface.Global.modifierAgent(self.agent, dic)
        else:
            boolean, res = self.parent.interface.Global.ajouterAgent(dic)
        
        
        if boolean:
            print(dic)
            self.parent.interface.initRepresentation()
            self.fin(1)
        else:
            print(res)
            
    
    def fin(self, done=0):
        self.parent.done(done)
        
"""
Retourne une chaine de caractère
"""        
def hexadecimalColor(number):
    a = number %16
    b = number // 16
    chaine=''
    if b < 10:
        chaine+=str(b)
    if b == 10:
        chaine+='A'
    if b == 11:
        chaine+='B'
    if b == 12:
        chaine+='C'
    if b == 13:
        chaine+='D'
    if b == 14:
        chaine+='E'
    if b == 15:
        chaine+='F'
        
    if a < 10:
        chaine+=str(a)
    if a == 10:
        chaine+='A'
    if a == 11:
        chaine+='B'
    if a == 12:
        chaine+='C'
    if a == 13:
        chaine+='D'
    if a == 14:
        chaine+='E'
    if a == 15:
        chaine+='F'
    return chaine
        
class Widget(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.Global = Global()
        
if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    app.setStyle("plastique")
    w = Widget()
    form = CreationAgent(w)
    w.show()
    form.show()
    sys.exit(app.exec_())