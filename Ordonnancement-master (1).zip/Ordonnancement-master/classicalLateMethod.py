# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 12:49:32 2018

@author: 3415104
"""

from time import time
class root():
    
    def __init__(self, taches, agents):
        t = time()
        self.taches =taches
        self.agents = agents
        self.nbNoeud = 0
        self.valOpti = []
        
        self.firstOrd()
        
        Noeud(self, [])
        
        self.temps = time() - t
    def firstOrd(self):
        ordonnancement = [tache for tache in self.taches]
        retard = self.classicalLateMethod(self.ordonnancement)
        self.changeOptimum(retard, ordonnancement)
    

    def classicalLateMethod(self, ordonnancement):
        retard = 0
        finOrd = 0
        for tache in ordonnancement:
            finOrd+=tache.duree
            for agent in self.agents:
                finAgent = agent.finTache[tache]
                if finOrd - finAgent > 0:
                     retard += finOrd - finAgent
        return retard
        
    def changeOptimum(self, retard, ordonnancement):
        self.late = retard
        self.ordonnancement = ordonnancement
        
        self.valOpti.append(self.late)
"""
Noeud de l'arbre représentant un ordonnancement partiel
"""
class Noeud():
    def __init__(self, root, ordonnancement):
        self.root = root
        self.ordonnancement = ordonnancement
        self.root.nbNoeud+=1
        """
        s=''
        for t in ordonnancement:
            s+=str(t.nom)
        print(s)
        """
        """
        Si c'est la fin
        """
        if len(ordonnancement) == len(self.root.taches):
            retard = self.root.classicalLateMethod(self.ordonnancement)
            if retard < self.root.late:
                self.root.changeOptimum(retard, ordonnancement)
                return

        dic={}
        for tache in [tache for tache in self.root.taches if tache not in self.ordonnancement]:
            dic[tache] = [self.borneInf(tache), self.borneSup(tache)]
        
        for tache in dic.keys():
            if not dic[tache][0] >= self.root.late:
                Noeud(self.root, [t for t in self.ordonnancement]+[tache])
    
    
    """
    Borne inf des noeuds fils
    """
    def borneInf(self, tache):
        ord = [t for t in self.ordonnancement]+[tache]
        retard = self.root.classicalLateMethod(ord)
        fin = sum([t.duree for t in ord])

        if len(ord) == len(self.root.taches):
            m=0
        else:
            m = min([t.duree for t in self.root.taches if t not in ord])
        
        fin +=m
        enPlus = 0
        for t in [t for t in self.root.taches if t not in ord]:
            for ag in self.root.agents:
                finAgent = ag.finTache[t]
                if fin - finAgent > 0:
                     enPlus += fin - finAgent

        return retard+enPlus
    
    """
    Borne sup des noeuds fils
    """
    def borneSup(self, tache):
        ord = [t for t in self.ordonnancement]+[tache]
        for t in self.root.taches:
            if t not in ord:
                ord.append(t)
        return self.root.classicalLateMethod(ord)
        
    
def nbNoeuds(n):
    if n==0:
        return 1
    else:
        return n*nbNoeuds(n-1) + 1
        