# -*- coding: utf-8 -*-

from BranchAndBound import *
from Fonction import *
from time import time
"""
Algorithm permettant d'ordonner des tâches selon les envies d'agents en leur affectant un score
Le score est égale au temps qu'il reste après la fin de cette tâche pour chaque agent
@param agents : Liste des agents ayant ordonner les tâche
"""
def PositionalScoringRules(agents):
    taches = agents[0].ordre
    f_score = [[0, tache] for tache in taches]
    
    descriptionApplication = "Application de l'algorithm PositionalScoringRules\n"
    
    for i in range(len(taches)):
        tache = taches[i]
        for agent in agents:
            trouve = False
            for tacheAgent in agent.ordre:
                if trouve:
                    f_score[i][0]+=tacheAgent.duree*agent.importance
                if tache == tacheAgent:
                    trouve = True
    for score, tache in f_score:
        descriptionApplication += "Le score de la tache "+tache.nom+" de duree "+str(tache.duree)+" est "+str(score)+"\n"
        
    sort = sorted(f_score, key=lambda colonnes: colonnes[0])
    sort.reverse()
    return descriptionApplication, [tache[1] for tache in sort], None

"""
Algorithm permettant d'ordonner des tâches selon les envies d'agents en utilisant la méthode PTA de Copeland
@param agents : Liste des agents ayant ordonner les tâche
"""
def PTACopelandMethod(agents):
    taches = agents[0].ordre
    f_score = [[0, tache] for tache in taches]
    
    descriptionApplication = "Application de l'algorithm PTACopelandMethod\n"
    
    for i in range(len(taches)):
        descriptionApplication+= taches[i].nom+" : "
        for tache in taches:
            
            if tache != taches[i]:
                coeff = (taches[i].duree*1.0 /(taches[i].duree*1.0 + tache.duree*1.0)) * len(agents)
                coeff = int(coeff)
                
                nbAgent = 0
                for agent in agents:
                    for tacheAgent in agent.ordre:
                        if tacheAgent == tache:
                            break
                        if tacheAgent == taches[i]:
                            nbAgent += agent.importance
                            
                if nbAgent > coeff:
                   f_score[i][0]+=1

    for score, tache in f_score:
        descriptionApplication += "Le score de la tache "+tache.nom+" de duree "+str(tache.duree)+" est "+str(score)+"\n"
        
    sort = sorted(f_score, key=lambda colonnes: colonnes[0])
    sort.reverse()
    return descriptionApplication, [tache[1] for tache in sort], None     


def IterativePTAMinimax(agents):

    res = []
    scores = []
    taches = agents[0].ordre
    totalAgents=0
    
    for agent in agents:
        totalAgents+=agent.importance
    
    for tache in taches :
        scores.append([tache,0])
    
    descriptionApplication = "Application de l'algorithm IterativePTAMinimax\n"
    
    while (taches):
        for i in range(len(taches)):
            descriptionApplication+= taches[i].nom+" : "
            for tache in taches:
                if tache != taches[i]:
                    coeff = (taches[i].duree*1.0 /(taches[i].duree*1.0 + tache.duree*1.0)) * totalAgents
                    nbAgent = 0
                    for agent in agents:
                        for tacheAgent in agent.ordre:
                            if tacheAgent == tache:
                                break
                            if tacheAgent == taches[i]:
                                nbAgent +=agent.importance
                    coeff -= nbAgent
                    coeff = max(0,coeff)
                
                    for score in scores:
                        if score[0] == taches[i]:
                            if score[1] < coeff:
                                score[1] = coeff
                   
        for score in scores :
            descriptionApplication += "Le score de la tache "+score[0].nom+" de duree "+str(score[0].duree)+" est "+str(score[1])+"\n"

        scoresorted = sorted(scores, key=lambda colonnes: colonnes[1])
        taches = []
        
        for i in range(len(scoresorted)):
            if i>0:
                taches.append(scoresorted[i][0])
        scores =[]
        
        for tache in taches :
            scores.append([tache,0])
            
        res.append(scoresorted[0])

    return descriptionApplication, [tache[0] for tache in res], None
    
    
def ChercheMaxOccurs(agents, taches, position):
    counts = []
    
    for tache in taches:
        count=0
        for agent in agents:
            if agent.ordre[position] == tache:
                count+=agent.importance
        counts.append(count)
        
    m = max(counts)
    indicesMaxi = [k for k, j in enumerate(counts) if j == m]
    res=[]
    
    for indice in indicesMaxi:
        res.append(taches[indice])
        
    return res
    
    
def MaxOccursEnd(agents):
    
    taches = agents[0].ordre
    res=[]
    tachesMax=taches
    
    descriptionApplication = "Application de l'algorithm MaxOccursEnd\n"
    
    
    for i in range(len(taches)-1,-1, -1):
        position = i
        while len(tachesMax)>1 and position >=0:
            tachesMax = ChercheMaxOccurs(agents, tachesMax, position)
            position -=1
       
        res.append(tachesMax[0])
        
        tachesMax =[x for x in taches if x not in res]
        
    res.reverse()
        
    return descriptionApplication, res , None 
    
    
class chercheLocale():
    
    def __init__(self, agents, calculValeursInitialement, methodInit, fonction, tempsMax):
        
        self.tempsStart = time()
        # Durée maximal autorisé
        self.tempsMax = tempsMax
        # Liste des agents
        self.agents = agents
        # On les tâches grâce au premier agent
        self.taches = self.agents[0].ordre
        # Boolean déterminant si on calcul les valeurs de chaques tâches pour chaque date initialement dans le but d'éviter les redondances
        self.calculValeursInitialement = calculValeursInitialement
        # Heuristique Initial
        self.methodInit = methodInit
        # Fonction mesurant l'impact entre la fin de tache dans l'ordonnancement et la fin de tache chez un agent
        self.fonction = fonction
        # Durée total des tâches
        self.duree = sum([tache.duree for tache in self.taches])
        # Ensemble des valeurs optimals local trouvées
        self.valeursOptimales = []
        
        self.ordonnancement = self.methodInit(self.agents)[1]

        # Si on decide de calculer initialement les valeurs        
        if self.calculValeursInitialement:
            self.initValues()

        self.start()
        
    """
    Calcul le nombre de fois que la tache est en retard à la date temps
    """
    def valeurTache(self, tache, temps):
        valeur = 0
        for ag in self.agents:
            valeur+= self.fonction(temps, ag.finTache[tache])*ag.importance
        return valeur
        
    """
    Initialisation des retard initiaux de chaques tâches pour chaques agents
    """
    def initValues(self):
        self.valeurTacheDate = {}
        for tache in self.taches:
            valeurTache = []
            for i in range(self.duree+1):
                valeurTache.append(self.valeurTache(tache, i))
            self.valeurTacheDate[tache] = valeurTache

        
    
    """
    Changer l'optimum
    """
    def changeOptimum(self, ord, valeur):
        self.valeur = valeur
        self.ordonnancement = ord
        print(valeur, [t.nom for t in ord])
        self.valeursOptimales.append(valeur)
    
    """
    Démarrage avec verification de tous les voisins
    """
    
    def startall(self):
        continuer = True
        nbTache = len(self.ordonnancement)
        while continuer and (time()-self.tempsStart < self.tempsMax):
            continuer = False
            for i in range(nbTache):
                for j in range(nbTache):
                    newOrd = [t for t in self.ordonnancement]
                    newOrd[i], newOrd[j] = newOrd[j], newOrd[i]
                    valeur = self.calculValeur(newOrd)
                    if valeur < self.valeur:
                        self.changeOptimum(newOrd, valeur)
                        continuer = True
                        
    """
    Démarrage, si un voisin propose une meilleure solution, on le choisit directement
    """
    
    def start(self):
        continuer = True
        nbTache = len(self.ordonnancement)
        while continuer and (time()-self.tempsStart < self.tempsMax):
            continuer = False
            for i in range(nbTache):
                for j in range(nbTache):
                    newOrd = [t for t in self.ordonnancement]
                    newOrd[i], newOrd[j] = newOrd[j], newOrd[i]
                    valeur = self.calculValeur(newOrd)
                    if valeur < self.valeur:
                        self.changeOptimum(newOrd, valeur)
                        continuer = True
                        break
                if continuer:
                    break
    
    def calculValeur(self, ord):
        return cost(self.agents, ord, self.fonction)

            
                
    